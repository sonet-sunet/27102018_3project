<?php 
$db = mysqli_connect('localhost', 'root', '', '27102018_3project');
mysqli_set_charset($db, 'utf8');