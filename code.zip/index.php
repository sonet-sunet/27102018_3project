<?php 
    include($_SERVER['DOCUMENT_ROOT'].'/parts/header.php');
?>

<?php 
    include($_SERVER['DOCUMENT_ROOT'].'/parts/footer.php');
?> 
